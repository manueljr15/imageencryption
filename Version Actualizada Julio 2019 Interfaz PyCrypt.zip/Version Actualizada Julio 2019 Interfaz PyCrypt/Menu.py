
#Importacion de librerias
from tkinter import *
import tkinter as tk
from Encriptar_Mensaje import encriptar
from Desencriptar_Mensaje import desencriptar
from tkinter import filedialog
from tkinter import messagebox as mb

#Funcion que permite seleccionar una imagen en el explorador de archivos desde la aplicacion
def interfaz():
    
    #nombre de la imagen a cargar
    global nombreimagen
    nombreimagen = ""
    
    #mensaje es el mensaje que devuelve la funcion, devuelve la ruta donde se encuentra la imagen
    Mensaje = ""
    filename =  filedialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("jpeg files","*.jpg"),("all files","*.*")))
    Mensaje = filename

    #ciclo que extrae el nombre de la imagen sin toda la ruta
    for letra in range(len(Mensaje)):
        
        if letra == 0:
            continue

        if Mensaje[-letra] == '/':
            break
        else:   
            nombreimagen = nombreimagen + Mensaje[-letra]
            
    #se verifica en consola que se obtuvo la ruta correcta
    print (filename)      
    
    #debido a que el mensaje se lee de izquierda a derecha este se tiene que invertir
    print(nombreimagen)       
    nombreimagen = nombreimagen[::-1]          
    print(nombreimagen)
    
    #Variable para obtener nombre de imagen e imprimirla
    name1.insert(0, nombreimagen)

#Funcion que llama el boton encriptar de menú
def enc():
    #Aviso de encriptación
    def aviso():
        mb.showinfo("Mensaje", "Mensaje encriptado correctamente")
        encriptar(name.get(), "ImagenesPrueba/"+nombreimagen, "ImagenesPrueba/"+nombreimagen)
    #Funcion para crear la ventana de encriptar
    def vent1():
        #Funcion para hacer transicion entre ventanas
        def close():
            raiz1.withdraw()
            raiz.deiconify()
        #Se crea ventana de encriptacion y se da formato
        raiz.withdraw()
        raiz1=tk.Toplevel()
        raiz1.title("Encriptacion")
        raiz1.resizable(0,0)
        raiz1.geometry("400x280")
        raiz1.iconbitmap("imagenes/mar.ico")
        raiz1.config(bg="#000000")
        #Imagen de fondo para ventana
        imagen = PhotoImage(file="imagenes/d.png")
        fondo=Label(raiz1, image=imagen).place(x=0,y=0)
        frame1 = LabelFrame(raiz1,bg="#58D68D")
        frame1.place(x=100, y=40)
        #Imagen a desencriptar
        global prub
        global name
        #Input para leer mensaje a encriptar
        Label(frame1, text="Mensaje: ", bg="#000000", fg="#FFFFFF").grid(row=1, column=1)
        name=Entry(frame1, bg="#FFFFFF")
        name.grid(row=1, column=2)
        #Nombre imagen encriptada
        global name1
        #Frame donde se ingresara nombre de imagen en la cual se encriptara
        frame2 = LabelFrame(raiz1,bg="#58D68D")
        frame2.place(x=100, y=70)
        #Label donde se mostrara nombre de imagen
        Label(frame2, text="Nombre imagen: ", bg="#000000", fg="#FFFFFF").grid(row=1, column=1)
        name1=Entry(frame2, bg="#FFFFFF")
        name1.grid(row=1, column=2)
        #Botones ventana encriptar
        boton= tk.Button(raiz1, text="Encriptar", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 10), background="#A1DE5D",command=lambda : aviso()).place(x=50,y=150)
        btn1= tk.Button(raiz1, text="Menu", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 10), background="#A1DE5D",command=lambda : close()).place(x=180,y=150)
        btn2= tk.Button(raiz1, text="Imagen", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 10), background="#A1DE5D",command=lambda : interfaz()).place(x=280,y=150)   
        raiz1=mainloop()
        
    vent1()

#Funcion que llama boton desencriptar de menu inicial
def dess():
    #Funcion para crear ventana de desencriptar
    def des():
        #Funcion para hacer transicion entre ventanas
        def close():
            raiz2.withdraw()
            raiz.deiconify()
        #Funcion para tomar mensaje desencriptado y mostrarlo
        def obtener():
            global mensaje
            mensaje=desencriptar("ImagenesPrueba/"+nombreimagen)
            frame1 = LabelFrame(raiz2,bg="#FFFFFF")
            frame1.place(x=0, y=45)
            #Label donde se muestra el mensaje desencriptado
            mn=Label(frame1, text=mensaje,bg="#268568", wraplength=250,height=5, width=56).grid(row=0, column=0)
        raiz.withdraw()
        raiz2=tk.Toplevel()
        raiz2.title("Desencriptar")
        raiz2.resizable(0,0)
        raiz2.iconbitmap("imagenes/mar.ico")
        raiz2.geometry("400x280")
        raiz2.config(bg="#000000")
        #Imagen de fondo ventana desencriptar
        imagen = PhotoImage(file="imagenes/d.png")
        fondo=Label(raiz2, image=imagen).place(x=0,y=0)
        #Nombre imagen a desencriptar
        global name1
        frame2 = LabelFrame(raiz2,bg="#58D68D")
        frame2.place(x=100, y=10)
        Label(frame2, text="Nombre imagen: ", bg="#000000", fg="#FFFFFF").grid(row=1, column=1)
        name1=Entry(frame2, bg="#FFFFFF")
        name1.grid(row=1, column=2)

        #Botones de ventana desencriptar
        boton= tk.Button(raiz2, text="Desencriptar", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 10), background="#A1DE5D",command=lambda : obtener()).place(x=60,y=180)
        btn1= tk.Button(raiz2, text="Menu", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 10), background="#A1DE5D",command=lambda : close()).place(x=190,y=180)
        btn2= tk.Button(raiz2, text="Imagen", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 10), background="#A1DE5D",command=lambda : interfaz()).place(x=300,y=180)
        raiz2=mainloop()
    
    des()
#Funcion para cargar ventana de informacion Python
def infPython():
    def close():
            raiz3.withdraw()
            raiz.deiconify()
    raiz.withdraw()
    raiz3=tk.Toplevel()
    raiz3.title("Python")
    raiz3.resizable(0,0)
    raiz3.iconbitmap("imagenes/mar.ico")
    raiz3.geometry("400x550")
    raiz3.config(bg="#FFFFFF")
    imagen = PhotoImage(file="imagenes/p.png")
        
    fondo=Label(raiz3, image=imagen).place(x=0,y=0)
    frame1 = LabelFrame(raiz3,bg="#FFFFFF")
    frame1.place(x=10, y=150)
        
    btn1= tk.Button(raiz3, text="Menú", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 18), background="#A1DE5D", command=lambda : close()).place(x=30,y=500)
                        
    raiz3=mainloop()
#Funcion para cargar ventana de informacion Encriptación
def infEncrip():
    def close():
            raiz3.withdraw()
            raiz.deiconify()
    raiz.withdraw()
    raiz3=tk.Toplevel()
    raiz3.title("Python")
    raiz3.resizable(0,0)
    raiz3.iconbitmap("imagenes/mar.ico")
    raiz3.geometry("400x550")
    raiz3.config(bg="#FFFFFF")
    imagen = PhotoImage(file="imagenes/encr.png")
        
    fondo=Label(raiz3, image=imagen).place(x=0,y=0)
    frame1 = LabelFrame(raiz3,bg="#FFFFFF")
    frame1.place(x=10, y=150)
        
    btn1= tk.Button(raiz3, text="Menú", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 18), background="#A1DE5D", command=lambda : close()).place(x=30,y=500)
                        
    raiz3=mainloop()
#Funcion para cargar ventana de informacion Tkinter
def infTkinter():
    def close():
            raiz3.withdraw()
            raiz.deiconify()
    raiz.withdraw()
    raiz3=tk.Toplevel()
    raiz3.title("Python")
    raiz3.resizable(0,0)
    raiz3.iconbitmap("imagenes/mar.ico")
    raiz3.geometry("400x550")
    raiz3.config(bg="#FFFFFF")
    imagen = PhotoImage(file="imagenes/t.png")
        
    fondo=Label(raiz3, image=imagen).place(x=0,y=0)
    frame1 = LabelFrame(raiz3,bg="#FFFFFF")
    frame1.place(x=10, y=150)
        
    btn1= tk.Button(raiz3, text="Menú", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 18), background="#A1DE5D", command=lambda : close()).place(x=30,y=500)
                        
    raiz3=mainloop()

#creación de ventana principal (Menú) y su formato
raiz=Tk()
raiz.title("Menú")
raiz.resizable(0,0)
raiz.geometry("400x300")
raiz.config(bg="#DBCBBC")
imagen = PhotoImage(file="imagenes/doss.png")
imagen1 = PhotoImage(file="imagenes/Logo.png")
fondo=Label(raiz, image=imagen).grid(row=0, column=0)   

#Label que muestra nombre de la aplicación
Label(raiz, text="PyCrypt",fg="#FFFFFF",image=imagen1, height=100, width=270,font=("Bradley Hand", 30)).place(x=60,y=80)

#Botones de ventana principal
btn1 = Button(raiz, text="Encriptar", activeforeground="#F50743",highlightbackground="#F3F31B", font=("Bradley Hand", 10), background="#A1DE5D", command=lambda : enc()).place(x=60,y=200)
btn2 = Button(raiz, text="Desencriptar", activeforeground="#F50743",highlightbackground="#F3F31B", relief="raised",font=("Bradley Hand", 10), command=lambda : dess()).place(x=250,y=200)
btn3 = Button(raiz, text="Python", activeforeground="#F50743", relief="groove",font=("Bradley Hand", 10), command=lambda : infPython()).place(x=22,y=18)
btn4 = Button(raiz, text="Encriptación", activeforeground="#F50743", relief="groove",font=("Bradley Hand", 10), command=lambda : infEncrip()).place(x=140,y=18)
btn5 = Button(raiz, text="Tkinter", activeforeground="#F50743", relief="groove",font=("Bradley Hand", 10), command=lambda : infTkinter()).place(x=300,y=18)
    
raiz=mainloop()